
from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from bson.regex import Regex
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
from datetime import datetime

app = Flask(__name__)
CORS(app)

from flask import render_template
@app.route("/")
def home():
    print(">> Ruta principal accedida")
    return render_template("index.html")

# MongoDB connection
client = MongoClient("mongodb+srv://admin:FpybIN95mvvtJbVr@spiritsbox.hp9nflo.mongodb.net/spiritsbox?retryWrites=true&w=majority")
db = client["SpiritsBox"]
customers_col = db["customers"]
drinks_col = db["drinks"]
history_col = db["recommendation_history"]

def build_profile_vector(prefix, items):
    return " ".join([f"{prefix}_{item}" for item in items])

@app.route("/recommendations", methods=["GET"])
def get_recommendations():
    name = request.args.get("name", "").strip()
    if not name:
        return jsonify({"error": "Missing 'name' parameter"}), 400

    cliente = customers_col.find_one({"name": Regex(f"^{name}$", "i")})
    if not cliente:
        return jsonify({"error": "Client not found"}), 404

    prefs = cliente.get("preferences", {})
    prefs_text = (
        build_profile_vector("type", prefs.get("types", [])) + " " +
        build_profile_vector("profile", prefs.get("flavor_profiles", [])) + " " +
        build_profile_vector("origin", prefs.get("origins", []))
    )

    bebidas = list(drinks_col.find())
    if not bebidas:
        return jsonify({"error": "No drinks found in database"}), 500

    df = pd.DataFrame(bebidas)
    df["text"] = df.apply(
        lambda row: f"type_{row.get('type', '')} " +
                    " ".join([f"profile_{p}" for p in row.get('flavor_profile', [])]) +
                    f" origin_{row.get('origin', '')}",
        axis=1
    )
    df["name"] = df["name"].fillna("Unnamed")

    vectorizer = CountVectorizer()
    vectors = vectorizer.fit_transform([prefs_text] + df["text"].tolist())
    similarity = cosine_similarity(vectors[0:1], vectors[1:]).flatten()

    df["similarity"] = similarity
    top_matches = df.sort_values(by="similarity", ascending=False).head(5)

    results = top_matches[["name", "type", "origin", "similarity"]].to_dict(orient="records")

    history_entry = {
        "customer_name": cliente["name"],
        "date": datetime.utcnow().isoformat(),
        "recommendations": results
    }
    history_col.insert_one(history_entry)

    return jsonify(results)

@app.route("/history", methods=["GET"])
def get_history():
    name = request.args.get("name", "").strip()
    if not name:
        return jsonify({"error": "Missing 'name' parameter"}), 400

    history = list(history_col.find({"customer_name": Regex(f"^{name}$", "i")}).sort("date", -1))
    for entry in history:
        entry["_id"] = str(entry["_id"])
    return jsonify(history)

@app.route("/customer")
def get_customer():
    name = request.args.get("name", "").strip()
    if not name:
        return jsonify({"error": "Missing 'name' parameter"}), 400
    cliente = customers_col.find_one({"name": Regex(f"^{name}$", "i")})
    if not cliente:
        return jsonify({"error": "Client not found"}), 404
    cliente["_id"] = str(cliente["_id"])
    return jsonify(cliente)

@app.route("/customer/update", methods=["POST"])
def update_customer():
    data = request.json
    name = data.get("name", "")
    prefs = data.get("preferences", {})
    result = customers_col.update_one({"name": Regex(f"^{name}$", "i")}, {"$set": {"preferences": prefs}})
    return jsonify({"success": result.modified_count > 0})

@app.route("/recommend_all", methods=["POST"])
def recommend_all():
    clientes = list(customers_col.find())
    bebidas = list(drinks_col.find())
    
    if not bebidas:
        return jsonify({"error": "No drinks found"}), 500

    df = pd.DataFrame(bebidas)
    df["text"] = df.apply(
        lambda row: f"type_{row.get('type', '')} " +
                    " ".join([f"profile_{p}" for p in row.get('flavor_profile', [])]) +
                    f" origin_{row.get('origin', '')}",
        axis=1
    )
    df["name"] = df["name"].fillna("Unnamed")

    vectorizer = CountVectorizer()
    text_corpus = df["text"].tolist()

    resultados = []

    for cliente in clientes:
        prefs = cliente.get("preferences", {})
        prefs_text = (
            build_profile_vector("type", prefs.get("types", [])) + " " +
            build_profile_vector("profile", prefs.get("flavor_profiles", [])) + " " +
            build_profile_vector("origin", prefs.get("origins", []))
        )
        if not prefs_text.strip():
            continue  # Skip cliente sin preferencias

        vectors = vectorizer.fit_transform([prefs_text] + text_corpus)
        similarity = cosine_similarity(vectors[0:1], vectors[1:]).flatten()
        df["similarity"] = similarity
        top_matches = df.sort_values(by="similarity", ascending=False).head(5)
        recs = top_matches[["name", "type", "origin", "similarity"]].to_dict(orient="records")

        history_entry = {
            "customer_name": cliente["name"],
            "date": datetime.utcnow().isoformat(),
            "recommendations": recs
        }
        history_col.insert_one(history_entry)
        resultados.append({"cliente": cliente["name"], "total": len(recs)})

    return jsonify({
        "clientes_procesados": len(resultados),
        "detalle": resultados
    })


if __name__ == "__main__":
    app.run(debug=True, port=5050)
